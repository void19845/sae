//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class Main {
    public static String RESET="\033[Om";
    public static String RED="\033[48;5;196m";
    public static String LIGHTRED="\0033[48;5;46m";
    public static String BLANC="\033[97m";
    public static void main(String[] args) {
        String[][] plateau =new String[8][8];
        plateau=Setup.MiseEnPlace(plateau);
        execution.afficher(plateau);
        execution.execution(plateau);
    }
}
