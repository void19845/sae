public class FinDeJeu {
    public static boolean peutJouer() {
        boolean jouer = true;
        if (Main.nbtpion < 0) {
            jouer = false;
        }
/*
        if (Main.nbjoueur1 + Main.nbtpion == 64 || Main.nbjoueur2 + Main.nbtpion == 64 ){
            jouer=false;

        }*/


        return jouer;
    }
}
