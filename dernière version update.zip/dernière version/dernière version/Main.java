//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class Main {
    /*
    public static String RESET="\033[Om";
    public static String RED="\033[48;5;196m";
    public static String LIGHTRED="\0033[48;5;46m";
    public static String BLANC="\033[97m";
    */
    public static boolean alternance = true;
    public static boolean gamestop = false;
    public static int nbtpion = 60;
    public static int nbjoueur1 = 2;
    public static int nbjoueur2 = 2;
    public static String[][] plateau = new String[8][8];


    public static void main(String[] args) {
        plateau = Setup.MiseEnPlace(plateau);
        Execution.execution(plateau);

    }
}
