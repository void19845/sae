

public class Setup {
    public static String[][] MiseEnPlace(String[][] plateau) {


        for (int i = 0; i < plateau.length; i++) {
            for (int j = 0; j < plateau[i].length; j++) {
                if (j % 2 == 0) {
                    if (i % 2 == 0) {
                        plateau[i][j] = " ";
                    } else {
                        plateau[i][j] = " ";
                    }

                } else if (j % 2 != 0) {
                    if (i % 2 == 0) {
                        plateau[i][j] = " ";
                    } else {
                        plateau[i][j] = " ";
                    }

                }
            }
        }
        plateau[3][3] = "●";
        plateau[3][4] = "○";
        plateau[4][3] = "○";
        plateau[4][4] = "●";
        return plateau;
    }
}


