import java.util.Scanner;

public class JoueurContreJoueur {
    public static void jeu(String[][] plateau) {
        Scanner sc = new Scanner(System.in);

        String joueur1;
        String joueur2;

        System.out.println("Joueur 1 choisissez un pseudo : ");
        joueur1 =sc.nextLine();

        System.out.println("Joueur 2 choisissez votre pseudo : ");
        joueur2 = sc.nextLine();

        while (!Main.gamestop) {
            execution.afficher(plateau);
            if (Main.alternance) {
                if (!FinDeJeu.peutJouer()) {
                    Main.gamestop = true;
                    System.out.println(joueur1 + "a perdu");

                }
                System.out.println(joueur1 + " ○ a vous de jouer");
                plateau=execution.gestionDéplacement(plateau);


                Main.alternance = false;
            } else if (!Main.alternance) {
                if (!FinDeJeu.peutJouer()) {
                    Main.gamestop = true;
                    System.out.println(joueur2 + "a perdu");
                }
                System.out.println(joueur2 + " ● a vous de jouer");
                plateau=execution.gestionDéplacement(plateau);

                Main.alternance = true;
            }
            Main.nbtpion--;

        }
    }
}
