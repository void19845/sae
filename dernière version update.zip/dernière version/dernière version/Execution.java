import java.util.Scanner;

public class Execution {
    public static void execution(String[][] plateau) {
        int modedejeu = 9;

        Scanner sc = new Scanner(System.in);
        //----------------------------------------------------------------------------------------------------------------------------------------------------
        //selection mode de jeu avec saisie forcée
        while (!Main.gamestop) {
            System.out.println("choisiser le mode de jeu \n 2: joueur contre joueur \n 1: joueur contre ia \n 0: ne pas jouer");
            modedejeu = sc.nextInt();

            switch (modedejeu) {

                case 2:
                    //------------------------------------------------------------------------------------------------------------------------------------------------------
                    //jeu entre deux joueur
                    JoueurContreJoueur.jeu(plateau);
                    break;


                case 1:
                    //-----------------------------------------------------------------------------------------------------------------------------------------------------------
                    //jeu contre ia
                    JoueurContreIa.jeuVSIA(plateau);
                    break;
                case 0:
                    //--------------------------------------------------------------------------------------------------------------------------------------------------------------------
                    //arrèt du jeu
                    System.out.println("bonne journée aurevoir");
                    Main.gamestop = true;
                    break;
            }
        }
    }

    public static void afficher(String[][] plateau) {
        boolean PremièreIteration = false;
        System.out.println();
        for (int i = 0; i < plateau.length; i++) {
            if (PremièreIteration) {
                System.out.println("|");
            }
            for (int j = 0; j < plateau.length; j++) {

                System.out.print("|" + plateau[i][j] + "");
                PremièreIteration = true;
            }
        }
        System.out.println("|\n il reste " + Main.nbtpion + " pion");

    }

    public static String[][] gestionDéplacement(String[][] plateau) {

        int positionX = 0;
        int positionY = 0;
        boolean entreecorrecte = false;
        Scanner sc = new Scanner(System.in);
        while (!entreecorrecte) {
            System.out.print("veuillez inserrez votre deplacement sous la forme  letre espace chifre : d 4    :");
            String deplacement = sc.nextLine();
            if (verifieSaisie(deplacement)) {
                positionX = conversionlettre(deplacement.charAt(0));
                positionY = conversionchifre(deplacement.charAt(2));
                if (verifieDeplacement(plateau, positionX, positionY)) {
                    plateau = executeDeplacement(plateau, positionX, positionY);
                    entreecorrecte = true;
                } else {
                    System.out.print("\ndeplacement non possible ");
                }
            } else {
                System.out.print("\nsaisie non correcte ");
            }
        }
        return plateau;
    }

    private static boolean verifieSaisie(String deplacement) {
        if (deplacement.length() == 3) {
            if (((deplacement.charAt(0) == 'a') || (deplacement.charAt(0) == 'b') || (deplacement.charAt(0) == 'c') || (deplacement.charAt(0) == 'd') || (deplacement.charAt(0) == 'e') || (deplacement.charAt(0) == 'f') || (deplacement.charAt(0) == 'g')) && ((deplacement.charAt(2) == '1') || (deplacement.charAt(2) == '2') || (deplacement.charAt(2) == '3') || (deplacement.charAt(2) == '4') || (deplacement.charAt(2) == '5') || (deplacement.charAt(2) == '6') || (deplacement.charAt(2) == '7') || (deplacement.charAt(2) == '8'))) {
                return true;
            }
        }
        return false;
    }

    public static boolean verifieDeplacement(String[][] plateau, int positionX, int positionY) {
        String JoueurActif;
        String JoueurPassif;
        if ((plateau[positionX][positionY] != "○") && (plateau[positionX][positionY] != "●")) {
            if (Main.alternance) {
                JoueurActif = "○";
                JoueurPassif = "●";
            } else {
                JoueurActif = "●";
                JoueurPassif = "○";
            }
            // vers le haut-----------------------------------------------------------------------------------------------------------------------------------------------------
            if (positionX!=0){
            if ((plateau[positionX + 1][positionY] == " ") || (plateau[positionX + 1][positionY] == JoueurActif)) {
            } else if (plateau[positionX + 1][positionY] == JoueurPassif) {
                for (int i = 0; i < plateau.length; i++) {
                    if ((plateau[positionX + i][positionY] != JoueurPassif) || (plateau[positionX + i][positionY] != JoueurActif)) {
                    } else if (plateau[positionX + i][positionY] == JoueurActif) {
                        return true;
                    }
                }

            }
            }
            // vers le bas --------------------------------------------------------------------------------------------------------------------------------------------------------------
            if (positionX!=8){
            if ((plateau[positionX - 1][positionY] == " ") || (plateau[positionX - 1][positionY] == JoueurActif)) {
            } else if (plateau[positionX - 1][positionY] == JoueurPassif) {
                for (int i = 0; i < plateau.length; i++) {
                    if ((plateau[positionX - i][positionY] != JoueurPassif) || (plateau[positionX - i][positionY] != JoueurActif)) {
                    } else if (plateau[positionX - i][positionY] == JoueurActif) {
                        return true;
                    }
                }

            }
        }
            //diagonalle haut droite--------------------------------------------------------------------------------------------------------------------------------------------------
           if ((positionX!=0) &&(positionY!=8)){
            if ((plateau[positionX + 1][positionY + 1] == " ") || (plateau[positionX + 1][positionY + 1] == JoueurActif)) {
            } else if (plateau[positionX + 1][positionY + 1] == JoueurPassif) {
                for (int i = 0; i < plateau.length; i++) {
                    if ((plateau[positionX + i][positionY + i] != JoueurPassif) || (plateau[positionX + i][positionY + i] != JoueurActif)) {
                    } else if (plateau[positionX + i][positionY + i] == JoueurActif) {
                        return true;
                    }
                }

            }
        }
            //diagonale bas gauche------------------------------------------------------------------------------------------------------------------------------------------------------------
            if ((positionX!=8)&&(positionX!=0)){
            if ((plateau[positionX - 1][positionY - 1] == " ") || (plateau[positionX - 1][positionY - 1] == JoueurActif)) {

            } else if (plateau[positionX - 1][positionY - 1] == JoueurPassif) {
                for (int i = 0; i < plateau.length; i++) {
                    if ((plateau[positionX - i][positionY - i] != JoueurPassif) || (plateau[positionX - i][positionY - i] != JoueurActif)) {
                    } else if (plateau[positionX - i][positionY - i] == JoueurActif) {
                        return true;
                    }
                }

            }
        }
            //vers la droite------------------------------------------------------------------------------------------------------------------------------------------------------------------------
            if (positionY!=8){
            if ((plateau[positionX][positionY + 1] == " ") || (plateau[positionX][positionY + 1] == JoueurActif)) {
            } else if (plateau[positionX][positionY + 1] == JoueurPassif) {
                for (int i = 0; i < plateau.length; i++) {
                    if ((plateau[positionX][positionY + i] != JoueurPassif) || (plateau[positionX][positionY + i] != JoueurActif)) {
                    } else if (plateau[positionX][positionY + i] == JoueurActif) {
                        return true;
                    }
                }

            }
        }
            //vers la gauche---------------------------------------------------------------------------------------------------------------------------------------------------------------------------
            if (positionY!=0){
            if ((plateau[positionX][positionY - 1] == " ") || (plateau[positionX][positionY - 1] == JoueurActif)) {
            } else if (plateau[positionX][positionY - 1] == JoueurPassif) {
                for (int i = 0; i < plateau.length; i++) {
                    if ((plateau[positionX][positionY - i] != JoueurPassif) || (plateau[positionX][positionY - i] != JoueurActif)) {
                    } else if (plateau[positionX][positionY - i] == JoueurActif) {
                        return true;
                    }
                }

            }
        }
            // diagonalle haut gauche---------------------------------------------------------------------------------------------------------------------------------------------------------------------
            if ((positionX!=0)&&(positionX!=8)){
            if ((plateau[positionX + 1][positionY - 1] == " ") || (plateau[positionX + 1][positionY - 1] == JoueurActif)) {
            } else if (plateau[positionX + 1][positionY - 1] == JoueurPassif) {
                for (int i = 0; i < plateau.length; i++) {
                    if ((plateau[positionX + i][positionY - i] != JoueurPassif) || (plateau[positionX + i][positionY - i] != JoueurActif)) {
                    } else if (plateau[positionX + i][positionY - i] == JoueurActif) {
                        return true;
                    }
                }

            }
        }
            // diagonalle bas droite---------------------------------------------------------------------------------------------------------------------------------------------------------------------------
            if ((positionX!=8)&&(positionX!=8)){
            if ((plateau[positionX - 1][positionY + 1] == " ") || (plateau[positionX - 1][positionY + 1] == JoueurActif)) {
            } else if (plateau[positionX - 1][positionY + 1] == JoueurPassif) {
                for (int i = 0; i < plateau.length; i++) {
                    if ((plateau[positionX - i][positionY + i] != JoueurPassif) || (plateau[positionX - i][positionY + i] != JoueurActif)) {
                    } else if (plateau[positionX - i][positionY + i] == JoueurActif) {
                        return true;
                    }

                }

            }

        }
        }
        return false;
    }

    //socupe de poser le pion------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
    private static String[][] executeDeplacement(String[][] plateau, int positionX, int positionY) {
        if (Main.alternance) {
            plateau[positionX][positionY] = "○";
        } else {
            plateau[positionX][positionY] = "●";
        }
        return plateau;
    }

    public static int conversionlettre(char val) {
        return (int) val - (int) 'a' + 1;
    }
    public static int conversionchifre(char val) {
        return (int) val - (int) '1' + 1;
    }


}





/*
    public static void afficher(String[][] plateau) {
        String background;
        for (int i = 0; i < plateau.length; i++) {
            System.out.println();
            for (int j = 0; j < plateau.length; j++) {
                if (((i + j) % 2) == 0) {
                    background = Main.RED;
                } else {
                    background = Main.LIGHTRED;
                }
                System.out.print(background + Main.BLANC + "|" + plateau[i][j] + ""+Main.RESET);
            }
        }
        System.out.println();

    }
    */
