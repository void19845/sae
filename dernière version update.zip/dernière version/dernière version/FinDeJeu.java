public class FinDeJeu {
    public static boolean peutJouer() {
        boolean jouer = true;
        if (Main.nbtpion < 0) {
            jouer = false;
        }
/*
        if (Main.nbjoueur1 + Main.nbtpion == 64 || Main.nbjoueur2 + Main.nbtpion == 64 ){
            jouer=false;

        }*/


        return jouer;
    }

    public static boolean actionPossible() {
        boolean actionPossible = true;


        for (int i = 0; i < 7; i++) {
            for (int j = 0; j < 7; j++) {
                actionPossible = Execution.verifieDeplacement(Main.plateau, i, j);
                if (actionPossible) {
                    return actionPossible;
                }
            }
        }

        return false;
    }
}
