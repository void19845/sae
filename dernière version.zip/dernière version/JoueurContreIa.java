public class JoueurContreIa {
    public static void jeuVSIA(String[][] plateau) {
        while (!Main.gamestop) {
            if (!FinDeJeu.peutJouer()) {
                Main.gamestop = true;
                System.out.println("vous avez perdu");
            }
            Execution.afficher(plateau);
            System.out.println("à vous de jouer");

            if (Main.alternance) {
                if (!FinDeJeu.peutJouer()) {
                    Main.gamestop = true;
                    System.out.println("L'IA à perdu");
                }
                Main.alternance = false;
            }
        }

    }
}
