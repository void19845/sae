import java.util.Scanner;

public class execution {
    public static void execution(String[][] plateau) {
        boolean alternance = false;
        boolean gamestop = false;
        int modedejeu = 9;
        int positionX = 0;
        int positionY = 0;
        Scanner sc = new Scanner(System.in);
        //----------------------------------------------------------------------------------------------------------------------------------------------------
        //selection mode de jeu avec saisie forcée
        while (!gamestop) {
            System.out.println("choisiser le mode de jeu \n 2: joueur contre joueur \n 1: joueur contre ia \n 0: ne pas jouer");
            modedejeu = sc.nextInt();
        }
        switch (modedejeu) {
            case 1:
                //------------------------------------------------------------------------------------------------------------------------------------------------------
                //jeu entre deux joueur
                while (!gamestop) {
                    afficher(plateau);
                    if (alternance) {
                        System.out.println("joueur.e.s noir as vous de jouer");

                        alternance = false;
                    } else if (!alternance) {
                        System.out.println("joueur.e.s blanc as vous de jouer");

                        alternance = true;
                    }
                    gamestop = false;
                }
                break;


            case 2:
                //-----------------------------------------------------------------------------------------------------------------------------------------------------------
                //jeu contre ia
                while (!gamestop) {
                    afficher(plateau);
                    System.out.println("joueur.e.s noir as vous de jouer");

                    if (alternance) {
                        gamestop = false;
                    }
                }
                break;
            case 0:
                //--------------------------------------------------------------------------------------------------------------------------------------------------------------------
                //arrèt du jeu
                System.out.println("bonne journée aurevoir");
                gamestop = true;
                break;

        }
    }

    public static void afficher(String[][] plateau) {
        boolean PremièreIteration=false;
        System.out.println();
        for (int i = 0; i < plateau.length; i++) {
            if (PremièreIteration) {
                System.out.println("|");
            }
            for (int j = 0; j < plateau.length; j++) {

                System.out.print("|" + plateau[i][j] + "");
                PremièreIteration=true;
            }
        }
        System.out.println("|\n");

    }

    
}





/*
    public static void afficher(String[][] plateau) {
        String background;
        for (int i = 0; i < plateau.length; i++) {
            System.out.println();
            for (int j = 0; j < plateau.length; j++) {
                if (((i + j) % 2) == 0) {
                    background = Main.RED;
                } else {
                    background = Main.LIGHTRED;
                }
                System.out.print(background + Main.BLANC + "|" + plateau[i][j] + ""+Main.RESET);
            }
        }
        System.out.println();

    }
    */
